#include "Search.h"


void SearchHistory::SetSearchTime()
{
    this->current_time = time(0);

    // Get the current time as a struct tm
    struct tm time_info;
    localtime_s(&time_info, &current_time);

    // Format the time string
    char dt[26];
    strftime(dt, sizeof(dt), "%Y-%m-%d %H:%M:%S", &time_info);

    // Now dt contains the formatted time string
    // You can store this string if needed
}

time_t SearchHistory::GetSearchTime()
{
    return current_time;
}

std::string SearchHistory::GetInputString()
{
    return this->Input;
}

void SearchHistory::SetInputString(std::string input)
{
    this->Input = input;
}

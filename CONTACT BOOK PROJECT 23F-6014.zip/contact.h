#pragma once
#pragma once
#pragma once
#include <string>
#include "Address.h"

class Contact {
private:
    int search_count;
    time_t current_time;
    std::string id;
    std::string first_name;
    std::string last_name;
    std::string mobile_number;
    std::string email_address;
    Address* address;


public:
    Contact(std::string first_name, std::string last_name, std::string mobile_number, std::string email_address, Address* address);

    void set_first_name(std::string first_name);
    std::string get_first_name();

    void set_last_name(std::string last_name);
    std::string get_last_name();

    void set_mobile_number(std::string mobile_number);
    std::string get_mobile_number();

    void set_email_address(std::string email_address);
    std::string get_email_address();

    void set_address(Address* address);
    Address* get_address();
    friend std::ostream& operator <<(std::ostream& COUT, Contact& contact);
    void display_Contact();
    bool operator==(const Contact& other) const;
    bool isContactEqual(Contact contact);
    Contact* copy_contact();

    Contact& operator = (const Contact& contact);


    void set_id(std::string id);
    std::string GetId();

    void SetSearchTime();
    time_t GetSearchTime();

    int GetSearchCount();
    void IncrementSearchCount();

    void Update(Contact contact);

    Contact();
};



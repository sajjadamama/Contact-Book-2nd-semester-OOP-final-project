#include <iostream>
#include <string>
# include<exception>
#include "contactbook.h"
#include "Group.h"
# include"Object.h"
# include "Search.h";
using namespace std;

void printMenu()
{
    std::cout << "-------------------- WELCOME TO THE CONTACT BOOK APP --------------------" << std::endl;
    std::cout << "Menu" << std::endl;
    std::cout << "[1] Create a contacts list " << std::endl;
    std::cout << "[2] Add new contact " << std::endl;
    std::cout << "[3] Search contact by name" << std::endl;
    std::cout << "[4] Search contact by phone number" << std::endl;
    std::cout << "[5] Search contact by address" << std::endl;
    std::cout << "[6] Print all contacts sorted by name" << std::endl;
    std::cout << "[7] Merge duplicate contacts" << std::endl;
    std::cout << "[8] Total contacts" << std::endl;
    std::cout << "[9] Save contacts to a file" << std::endl;
    std::cout << "[10] Load contacts from a file" << std::endl;
    std::cout << "[11] Search By Single Word" << std::endl;
    std::cout << "[12] Open Group Menu" << std::endl;
    std::cout << "[13] Exit" << std::endl;
    std::cout << "Select what you want from given options (1-11) = ";
}

class Exception : public exception
{
public:
    void what()
    {
        std::cout << "404 error... Exception occured!" << std::endl;
    }
};

int main()
{

    string first_name, last_name, mobile_number, email_address, city, country, street, house, file_name, choice;
    ContactBook contact_book(20);
    file_name = "dataxyz";
    int select;
    Group* groups = new Group[10]; // Moved the declaration outside the loop
    do
    {
        printMenu();
        std::cin >> select;
        while (std::cin.fail())
        {
            std::cout << "Invalid Input! Must enter an integer only" << std::endl;
            std::cin.clear();
            std::cin.ignore();
            std::cout << "Please input again from option 1-11 = ";
            std::cin >> select;
        }

        switch (select)
        {
        case 1:
        {
            int size, option;
            cout << "Contact list already exist.Press 1 if want to creat new or press 0 if not =";
            cin >> option;
            if (option == 1)
            {
                std::cout << "Enter the size of contacts list =";
                std::cin >> size;
                ContactBook contact_book_obj(size);
                std::cout << "Contact list created of size =" << size << endl;
                break;
            }
            else
                break;
        }
        case 2:
        {

            Contact contact;
            Address address;

            std::cout << "Enter House No =";
            std::cin.ignore();
            std::getline(cin, house);
            std::cin.ignore();
            address.setHouse(house);
            std::cin.ignore();
            std::cout << "Enter Street =";
            std::getline(std::cin, street);
            address.setStreet(street);

            std::cout << "Enter City =";
            std::getline(std::cin, city);
            address.setCity(city);

            std::cout << "Enter Country =";
            std::getline(std::cin, country);
            address.setCountry(country);

            std::cout << "Enter First Name =";
            std::getline(std::cin, first_name);
            contact.set_first_name(first_name);

            std::cout << "Enter Last Name =";
            std::getline(std::cin, last_name);
            contact.set_last_name(last_name);

            std::cout << "Enter Mobile Number =";
            std::getline(std::cin, mobile_number);
            contact.set_mobile_number(mobile_number);

            std::cout << "Enter Email Address =";
            std::getline(std::cin, email_address);
            contact.set_email_address(email_address);

            contact.set_address(&address);
            contact_book.add_contact(contact);
            contact_book.save_to_file(file_name);
            cout << endl;

            break;
        }

        case 3:
        {
            string first_name, last_name;
            cout << "Enter first name to search =";
            cin >> first_name;
            cout << "Enter last name to search =";
            cin >> last_name;

            Contact* foundContact = contact_book.search_contact(first_name, last_name);
            if (foundContact != nullptr)
            {
                cout << "Contact found" << endl;
                foundContact->display_Contact();
            }
            else
            {
                cout << "Contact not found.";
            }

            break;

        }
        case 4:
        {
            string search_phone;
            cout << "Enter phone number you want to search=";
            cin >> search_phone;
            while (search_phone.length() < 11)
            {
                cout << "Phone number must consist 11 digits" << endl;
                cout << "Please enter correct information =";
                cin >> search_phone;
            }
            if (cin.fail())
            {
                cout << "Invalid input" << endl;
                cin.clear();
                cin.ignore();
                cin >> search_phone;

            }

            Contact* foundContact = contact_book.search_contact(search_phone);
            if (foundContact != nullptr)
            {
                cout << "Contact found:\n";
                foundContact->display_Contact();
            }
            else
            {
                cout << "No contact match according to given data" << endl;
            }
            break;
        }
        case 5:
        {
            string search_house, search_street, search_city, search_country;
            cout << "Enter address details" << endl;;
            cout << "Enter house =";
            cin >> search_house;
            cout << "Enter street =";
            cin >> search_street;
            cout << "Enter city =";
            cin >> search_city;
            cout << "Enter country =";
            cin >> search_country;

            Address searchAddress(search_house, search_street, search_city, search_country);
            Contact* foundContact = contact_book.search_contact(searchAddress);
            if (foundContact != nullptr)
            {
                cout << "Contact found" << endl;
                foundContact->display_Contact();
            }
            else

                cout << "NO contact found according to given data." << endl;

            break;
        }
        case 6:
        {
            string choice;
            cout << "Type first_name" << endl;
            cout << "Type last_name" << endl;
            cout << "Enter how you want to sort contacts =";
            cin.ignore();
            getline(cin, choice);
            contact_book.print_contacts_sorted(choice);
            break;
        }
        case 7:
        {
            contact_book.merge_duplicates();
            break;
        }
        case 8:
        {
            cout << "Displaying Total contacts " << endl;
            contact_book.total_contacts();
            cout << endl;
            break;
        }


        case 9:
        {
            string file_name;
            cout << "Enter the name of file in which you want to save contacts = ";
            cin >> file_name;
            contact_book.save_to_file(file_name);

            break;
        }
        case 10:
        {
            string file_name;
            cout << "Enter the name of file =";
            cin >> file_name;
            contact_book.load_from_file(file_name);
            cout << "Contacts loaded from file." << endl;
            break;
        }
        case 11:
        {
            std::string word;
            std::cout << "Enter any Word to Search about in the List =" << std::endl;
            std::cin >> word;
            ContactBook other;
            std::cout << other.search_contact(word)->GetId() << " ";
            std::cout << other.search_contact(word)->get_first_name() << " ";
            std::cout << other.search_contact(word)->get_last_name() << " " << std::endl;
        }
        case 12:
        {
            std::cout << "[1].Make a Group" << endl;;
            std::cout << "[2].Add a Contact" << endl;
            std::cout << "[3].Remove a Contact" << endl;
            std::cout << "[4].Search in Group" << endl;
            std::cout << "[5].Display Group Contacts" << endl;
            std::cout << "[6].Delete a Group" << std::endl;
            int choice;
            cin >> choice;
            switch (choice)
            {
            case 1:
            {
                int modified = 0;
                std::string name;
                std::cout << "Enter the name of Group =" << std::endl;
                std::cin >> name;
                std::cout << "Enter the size of Group =" << std::endl;
                int size;
                std::cin >> size;

                Group obj(name, size);
                for (int i = 0; i < Group::group_count; ++i)
                {
                    if (groups[i] == obj)
                    {
                        std::cout << "Group already exists" << std::endl;
                        break;
                    }

                    modified = i;
                }
                groups[modified + 1] = obj;

                break;
            }
            case 2:
            {
                int choice;
                std::cout << "[1] Add to Existing groups" << endl;
                std::cout << "[2] Make new group" << std::endl;
                std::cin >> choice;
                switch (choice)
                {
                case 1:
                {
                    std::cout << "----Available Groups----" << std::endl;

                    for (int i = 0; i < Group::group_count; i++)
                    {
                        std::cout << groups[i].GetGroupName() << std::endl;
                    }
                    std::cout << "Choose a Group " << std::endl;
                    std::string select;
                    std::cin >> select;
                    for (int i = 0; i < Group::group_count; i++)
                    {
                        if (select == groups[i].GetGroupName())
                            groups[i].add_in_group();
                    }
                    break;
                }
                case 2:
                {
                    system("cls");
                    std::string group_name;
                    int size;
                    std::cout << "Enter Name of group =" << std::endl;
                    std::cin >> group_name;
                    std::cout << "Enter Size of group =" << std::endl;
                    std::cin >> size;
                    Group obj(group_name, size);
                    for (int i = 0; i < Group::group_count;)
                    {
                        if (groups[i] == obj)
                        {
                            i++;
                        }
                        else
                        {
                            groups[i] = obj;
                            groups[i].add_in_group();
                        }
                    }
                    break;
                }
                default:break;
                }
            case 3:
            {
                std::cout << "----Available Groups----" << std::endl;

                for (int i = 0; i < Group::group_count; i++)
                {
                    std::cout << groups[i].GetGroupName() << std::endl;
                }
                std::cout << "Choose a Group " << std::endl;
                std::string select_name;
                std::cin >> select_name;
                std::string select_contact;
                std::cout << "Enter a Contact to Remove" << std::endl;
                std::cin >> select_contact;
                for (int i = 0; i < Group::group_count; i++)
                {
                    if (select_name == groups[i].GetGroupName())
                        groups[i].remove_a_contact(select_contact);
                }
                break;
            }
            case 4:
            {
                std::cout << "Enter an Id to search about Contact" << std::endl;
                std::string contact;
                std::cin >> contact;
                for (int i = 0; i < Group::group_count; i++)
                {
                    Contact searched = groups[i].search_in_group(contact);
                    if (searched.GetId() == contact)
                        std::cout << searched << std::endl << "This Contact is a part of " << groups[i].GetGroupName() << std::endl;
                }
                break;
            }case 5:
            {
                std::string group_name;
                std::cout << "Enter Group Name =";
                std::cin >> group_name;
                for (int i = 0; i < Group::group_count; i++)
                {
                    if (groups[i].GetGroupName() == group_name)
                    {
                        system("cls");
                        std::cout << "------" << groups[i].GetGroupName() << "-------" << endl;
                        groups[i].Display_group_members();
                    }
                    else
                        std::cout << "\n**No Such Group exists**\n";

                }
                break;
            }
            case 6:
            {

                std::cout << "----Existing Groups----" << std::endl;

                for (int i = 0; i < Group::group_count; i++)
                {
                    std::cout << groups[i].GetGroupName() << std::endl;
                }
                std::cout << "Select a Group " << std::endl;
                std::string select_name;
                std::cin >> select_name;
                int end_count = Group::group_count;
                for (int i = 0; i < Group::group_count; i++)
                {
                    if (select_name == groups[i].GetGroupName())
                    {
                        for (int j = i; j < end_count; j++)
                        {
                            groups[j] = groups[j + 1];
                        }
                        std::cout << "Contact removed Successfully" << std::endl;
                        Group::group_count--;
                        end_count--;
                    }
                    else
                        i++;
                }

                break;
            }
            default:break;
            }
            }
        case 13:
        {
            cout << "Exiting........";
            break;
        }

        default:
        {
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }

        }


        }
    } while (select != 13);

    delete[] groups; // Free the memory allocated for groups
    std::cout << "Exiting........" << std::endl;
    system("pause");
    return 0;
}

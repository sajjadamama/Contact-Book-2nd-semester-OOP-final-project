# include<iomanip>
#include "Object.h"

int Objects::history_count = 0;

Objects::Objects()
{
    history_limit = 10;
    history_list = new SearchHistory[history_limit];
    history_count++;
}
SearchHistory* Objects::GetSearchHistory()
{
    return this->history_list;
}
void Objects::PrintSearchHistory()
{
    for (int i = history_count - 1; i >= 0; --i) // Iterate over search history entries
    {
        std::cout << this->history_list[i].GetInputString() << " "; // Print input string

        // Get search time of the current history entry
        time_t current_time = this->history_list[i].GetSearchTime();

        // Convert search time to a tm struct using localtime_s
        struct tm timeinfo;
        if (localtime_s(&timeinfo, &current_time) == 0)
        {
            // Format the time using std::put_time
            std::cout << std::put_time(&timeinfo, "%Y-%m-%d %H:%M:%S") << std::endl;
        }
        else
        {
            std::cout << "Error: Failed to convert time" << std::endl;
        }
    }
}


SearchHistory Objects::resize_history_list()
{
    SearchHistory* history_list_2;
    history_list_2 = new SearchHistory[history_limit * 2];
    for (int i = 0; i < history_limit; i++)
    {
        history_list_2[i] = history_list[i];
    }
    delete[] history_list;
    history_list = history_list_2;
    return *history_list_2;
}
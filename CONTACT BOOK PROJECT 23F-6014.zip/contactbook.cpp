#include "contactbook.h"
# include<sstream>
# include<stdexcept>
using namespace std;
ContactBook::ContactBook() {}

ContactBook::ContactBook(int size_of_list) {
    this->contacts_list = new Contact[size_of_list];
    this->size_of_contacts = size_of_list;
    this->contacts_count = 0;
}

void ContactBook::add_contact(const Contact& contact) {
    if (this->isfull()) {
        this->resize_list();
    }
    this->contacts_list[this->contacts_count] = contact;
    contacts_count++;
}

int ContactBook::total_contacts()
{
    std::cout << "Number of total contacts =" << contacts_count;
    std::cout << std::endl;
    for (int i = 0; i < contacts_count; ++i)
    {
        contacts_list->display_Contact();
        contacts_list++;
    }
    return contacts_count;
}

bool ContactBook::isfull() {
    if (this->contacts_count == this->size_of_contacts)
        return true;
    else
        return false;
}
void ContactBook::set_contacts_count(int other)
{
    contacts_count = other;

}

Contact* ContactBook::get_contact_list() {
    return contacts_list;
}

void ContactBook::resize_list() {
    int size = 2 * this->size_of_contacts;
    Contact* obj = new Contact[size];
    for (int i = 0; i < contacts_count; i++) {
        obj[i] = this->contacts_list[i];
    }
    delete[] contacts_list;
    contacts_list = obj;
    this->size_of_contacts *= 2;
}

Contact* ContactBook::search_contact(std::string first_name, std::string last_name)
{
    for (int i = 0; i < contacts_count; ++i) {
        if (contacts_list[i].get_first_name() == first_name && contacts_list[i].get_last_name() == last_name)
        {
            return &contacts_list[i];
        }
    }
    std::cout << "No Contact Found according to given First and Last name!" << std::endl;
    return nullptr;
}

int compare(Contact* contacts1, Contact* contacts2, std::string choice) {
    if (choice == "first_name") {
        return contacts1->get_first_name() <= contacts2->get_first_name() ? 1 : -1;
    }
    else if (choice == "last_name") {
        return contacts1->get_last_name() <= contacts2->get_last_name() ? 1 : -1;
    }
}

Contact* ContactBook::search_contact(std::string phone) {
    for (int i = 0; i < size_of_contacts; ++i) {
        if (contacts_list[i].get_mobile_number() == phone) {
            return &contacts_list[i];
        }
    }
    std::cout << "No Contact found according to given Phone Number!" << std::endl;
    return nullptr;
}

Contact* ContactBook::search_contact(const Address& address) {
    for (int i = 0; i < size_of_contacts; ++i) {
        if (*(contacts_list[i].get_address()) == address) {
            return &contacts_list[i];
        }
    }
    std::cout << "No Contact found according to given address!" << std::endl;
    return nullptr;
}
Contact* ContactBook::copy(Contact contact_list)
{
    Contact* copy_contacts_list = new Contact[contacts_count];
    for (int i = 0; i < contacts_count; i++)
    {
        copy_contacts_list[i] = contacts_list[i];
    }
    return copy_contacts_list;
}
void ContactBook::sort_contacts_list(Contact* contacts_list, std::string choice) {
    for (int i = 0; i < contacts_count; i++) {
        for (int j = i + 1; j < contacts_count; j++) {
            Contact temp;
            if (compare(&contacts_list[j], &contacts_list[i], choice) == 1) {
                temp = contacts_list[j];
                contacts_list[j] = contacts_list[i];
                contacts_list[i] = temp;
            }
        }
    }
}
void ContactBook::print_contacts_sorted(std::string choice)
{
    Contact* contacts = ContactBook::copy(*this->contacts_list);
    ContactBook::sort_contacts_list(contacts, choice);

    for (int i = 0; i < contacts_count; i++)
    {
        std::cout << contacts[i].get_first_name() << " " << contacts[i].get_last_name() << " ";
        std::cout << std::endl;
    }
}



ContactBook& ContactBook::operator=(const ContactBook& contacts_book) {
    if (this != &contacts_book) {
        this->size_of_contacts = contacts_book.size_of_contacts;
        this->contacts_count = contacts_book.contacts_count;
        for (int i = 0; i < contacts_count; i++) {
            this->contacts_list[i] = contacts_book.contacts_list[i];
        }
    }
    return *this;
}

void ContactBook::merge_duplicates() {
    int count_end = contacts_count;

    // Iterate through the contacts
    for (int i = 0; i < count_end; ++i) {
        // Check for duplicates starting from the next contact
        for (int j = i + 1; j < count_end;) {
            if (contacts_list[i] == contacts_list[j]) {
                // Shift the contacts to remove the duplicate
                for (int k = j; k < count_end - 1; ++k) {
                    contacts_list[k] = contacts_list[k + 1];
                }
                // Decrease the count of contacts
                --count_end;
            }
            else {
                // Move to the next contact
                ++j;
            }
        }
    }

    // Output the merged contacts
    for (int i = 0; i < count_end; ++i) {
        std::cout << this->contacts_list[i].get_first_name() << " "
            << this->contacts_list[i].get_last_name() << " "
            << this->contacts_list[i].get_email_address() << std::endl;
        this->contacts_list[i].get_address()->printaddress();
        std::cout << std::endl;
    }

    // Output the count of merged contacts
    std::cout << "Contacts Merged  =" << contacts_count - count_end << std::endl;
}


void ContactBook::addContact(const Contact& contact) {
    if (isfull()) {
        resize_list();
    }
    contacts_list[contacts_count++] = contact;
}
std::ostream& operator <<(std::ostream& cout, ContactBook& contacts_book)
{
    for (int i = 0; i < contacts_book.contacts_count; i++)
    {
        std::cout << contacts_book.contacts_list[i];
    }
    return cout;
}


bool ContactBook::is_duplicate(const Contact& contact) const
{
    for (int i = 0; i < contacts_count; i++)
    {
        if (contacts_list[i] == contact)
        {
            return true;
        }
    }
    return false;
}
void ContactBook::load_from_file(std::string file_name)
{
    std::ifstream file(file_name);
    if (file.is_open())
    {
        int count;
        file >> count;
        file.ignore(); // Ignore the newline character after count

        for (int i = 0; i < count; i++) {
            std::string line;
            getline(file, line); // Read the entire line

            std::stringstream ss(line);
            std::string first_name, last_name, mobile_number, email_address, house, street, city, country;

            getline(ss, first_name, ',');
            getline(ss, last_name, ',');
            getline(ss, mobile_number, ',');
            getline(ss, email_address, ',');
            getline(ss, house, ',');
            getline(ss, street, ',');
            getline(ss, city, ',');
            getline(ss, country, ',');

            Contact contact;
            contact.set_first_name(first_name);
            contact.set_last_name(last_name);
            contact.set_mobile_number(mobile_number);
            contact.set_email_address(email_address);

            Address address;
            address.setHouse(house);
            address.setStreet(street);
            address.setCity(city);
            address.setCountry(country);

            contact.set_address(&address);

            this->add_contact(contact);
        }
        file.close();
    }
    else {
        std::cout << "Error: File not open" << std::endl;
    }
}

void ContactBook::save_to_file(std::string file_name) {
    int count = 0;
    size_t pos = 0; // Declaration of pos
    std::string count_str; // Declaration of count_str
    std::string contacts_str; // Declaration of contacts_str

    // Read the existing contacts from the file
    std::ifstream file_in(file_name);
    if (file_in.is_open()) {
        std::stringstream file_content;
        file_content << file_in.rdbuf();
        file_in.close();

        // Extract the contacts from the file content
        contacts_str = file_content.str(); // Assignment of contacts_str

        // Find the position of the first newline character
        pos = contacts_str.find_first_of('\n'); // Assignment of pos

        if (pos != std::string::npos) {
            // Extract the count string
            count_str = contacts_str.substr(0, pos); // Assignment of count_str
            try {
                // Convert the count string to integer
                count = std::stoi(count_str);
            }
            catch (const std::invalid_argument& e)
            {
                std::cout << "Invalid count in the file: " << e.what() << std::endl;
                return;
            }
        }
    }
    else {
        std::cout << "Failed to open file: " << file_name << std::endl;
        return;
    }

    // Open the file in truncation mode to overwrite only the count
    std::ofstream fout(file_name, std::ios::trunc);
    if (!fout.is_open()) {
        std::cout << "Failed to open file for writing: " << file_name << std::endl;
        return;
    }

    // Write the updated count
    fout << this->contacts_count + count << std::endl;

    // Write back the previously stored contacts (if any)
    if (pos != std::string::npos) {
        fout << contacts_str.substr(pos + 1); // Write the contacts excluding the count
    }

    // Write new contacts
    for (int i = 0; i < contacts_count; i++)
    {
        std::stringstream ss;
        ss << this->contacts_list[i].get_first_name() << ","
            << this->contacts_list[i].get_last_name() << ","
            << this->contacts_list[i].get_mobile_number() << ","
            << this->contacts_list[i].get_email_address() << ","
            << this->contacts_list[i].get_address()->getHouse() << ","
            << this->contacts_list[i].get_address()->getStreet() << ","
            << this->contacts_list[i].get_address()->getCity() << ","
            << this->contacts_list[i].get_address()->getCountry() << std::endl;
        fout << ss.str();
    }
    std::cout << "Saving contact. Please wait . . . . . ." << endl;
    std::cout << "Contact saved in file" << std::endl;
}



ContactBook::~ContactBook()
{
    delete[] contacts_list;
}

//Extended functions

void ContactBook::ViewDetails(std::string input)
{
    Contact obj = this->single_string_contact(input);
    system("cls");
    std::cout << obj.GetId() << " " << obj.get_first_name() << " " << obj.get_last_name() << " " << obj.get_address() << std::endl << obj.get_mobile_number() << " " << obj.get_email_address() << std::endl;
    system("cls");
    std::cout << "------Menu-----" << std::endl;
    std::cout << "1.Update" << endl;
    std::cout << "2.Delete" << std::endl;
    int option;
    std::cin >> option;
    switch (option) {
    case 1:
    {
        std::string first_name, last_name, mobile_number, email_address, city, country, street, house, file_name;
        std::cin >> file_name;
        Contact contact;
        Address address;
        std::cout << "House ";
        std::cin.ignore();
        std::getline(std::cin, house);
        std::cin.ignore();
        address.setHouse(house);

        std::cin.ignore();
        std::cout << "Street: ";
        std::getline(std::cin, street);
        address.setStreet(street);

        std::cout << "City: ";
        std::getline(std::cin, city);
        address.setCity(city);

        std::cout << "Country: ";
        std::getline(std::cin, country);
        address.setCountry(country);


        std::cout << "First Name: ";
        std::getline(std::cin, first_name);
        contact.set_first_name(first_name);

        std::cout << "Last Name: ";
        std::getline(std::cin, last_name);
        contact.set_last_name(last_name);

        std::cout << "Mobile Number: ";
        std::getline(std::cin, mobile_number);
        contact.set_mobile_number(mobile_number);

        std::cout << "Email Address: ";
        std::getline(std::cin, email_address);
        contact.set_email_address(email_address);

        contact.set_address(&address);


        obj.Update(contact);
        this->save_to_file(file_name);

    }
    case 2:
    {
        std::string input;
        std::cout << "Enter a string to delete" << std::endl;
        std::cin >> input;
        Contact obj = this->single_string_contact(input);
        this->Remove_contact(obj);
    }

    }

}
void ContactBook::frequentlySearched()
{

    Contact* contacts = ContactBook::copy(*this->contacts_list);
    for (int i = 0; i < this->contacts_count - 1; i++) {
        for (int j = 0; j < this->contacts_count - i - 1; j++) {
            if (contacts[j].GetSearchCount() < contacts[j + 1].GetSearchCount()) {
                Contact temp = contacts[j];
                contacts[j + 1] = contacts[j];
                contacts[j] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        std::cout << contacts[i] << std::endl;
    }

}

ContactBook ContactBook::Remove_contact(Contact searched)
{
    int end_count = contacts_count;
    for (int i = 0; i < end_count;)
    {
        if (this->contacts_list[i] == searched)
        {
            for (int j = i; j < end_count - 1; j++) {
                contacts_list[i] = contacts_list[i + 1];
            }
            end_count--;
            this->contacts_count--;
        }
        else i++;
    }
    this->save_to_file("update");
    return *this;
}

Contact ContactBook::single_string_contact(std::string String)
{

    for (int i = 0; i < this->contacts_count; i++) {
        int count = 0;
        std::string windows[5];
        windows[0] = this->contacts_list[i].get_first_name() + contacts_list[i].get_last_name();
        windows[1] = this->contacts_list[i].get_address()->getCity();
        windows[2] = this->contacts_list[i].get_email_address();
        windows[3] = this->contacts_list[i].get_mobile_number();
        windows[4] = this->contacts_list[i].GetId();
        for (int j = 0; j < 5; j++) {
            for (int k = 0; k < windows[j].size(); k++) {
                if (String[count] == windows[j][k]) {
                    count++;
                }
                if (count == String.size()) {
                    contacts_list[i].IncrementSearchCount();
                    contacts_list[i].SetSearchTime();
                    return this->contacts_list[i];
                }
            }
        }
        std::string search_phone = contacts_list[i].get_mobile_number();
        std::string search_email = contacts_list[i].get_address()->getHouse();
        std::string f_name = contacts_list[i].get_first_name();
        std::string l_name = contacts_list[i].get_last_name();
        std::string search_id = contacts_list[i].GetId();
        if (search_phone == String || search_email == String || search_id == String || f_name == String || l_name == String) {
            contacts_list[i].IncrementSearchCount();
            contacts_list[i].SetSearchTime();
            return contacts_list[i];
        }

    }
}


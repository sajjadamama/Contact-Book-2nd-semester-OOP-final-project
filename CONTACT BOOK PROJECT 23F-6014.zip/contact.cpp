#include "Contact.h"

Contact::Contact()
{
    address = new Address;
    this->search_count = 0;
}

Contact::Contact(std::string first_name, std::string last_name, std::string mobile_number, std::string email_address, Address* address) {
    if (first_name.length() > 0)
        this->first_name = first_name;
    else
        std::cout << "Incorrect input" << std::endl;

    if (last_name.length() > 0)
        this->last_name = last_name;
    else
        std::cout << "Incorrect input" << std::endl;

    if (mobile_number.length() == 11)
        this->mobile_number = mobile_number;
    else
        std::cout << "Incorrect input" << std::endl;

    if (email_address.length() > 0)
        this->email_address = email_address;
    else
        std::cout << "Incorrect input" << std::endl;

    this->address = address;

    this->search_count = 0;
}

void Contact::set_first_name(std::string first_name) {
    if (first_name.length() > 0)
        this->first_name = first_name;
}

void Contact::set_last_name(std::string last_name) {
    if (last_name.length() > 0)
        this->last_name = last_name;
}

void Contact::set_mobile_number(std::string mobile_number) {
    if (mobile_number.length() == 11)
        this->mobile_number = mobile_number;
}

void Contact::set_email_address(std::string email_address) {
    if (email_address.length() > 0)
        this->email_address = email_address;
}

void Contact::set_address(Address* address) {
    *this->address = address->copy_address();
}

void Contact::set_id(std::string id)
{
    if (id.length() > 0)
        this->id = id;
}

void Contact::SetSearchTime()
{
    this->current_time = time(0);
    // Get the current time as a struct tm
    struct tm time_info;
    localtime_s(&time_info, &current_time);

    // Format the time string
    char dt[26];
    strftime(dt, sizeof(dt), "%Y-%m-%d %H:%M:%S", &time_info);

    // Now dt contains the formatted time string
    // You can store this string if needed

}

std::string Contact::get_first_name() {
    return this->first_name;
}

std::string Contact::get_last_name() {
    return this->last_name;
}

std::string Contact::get_mobile_number() {
    return this->mobile_number;
}

std::string Contact::get_email_address() {
    return this->email_address;
}

Address* Contact::get_address() {
    return this->address;
}

time_t Contact::GetSearchTime() {

    return this->current_time;
}

int Contact::GetSearchCount() {
    return this->search_count;
}
std::string Contact::GetId() {
    return this->id;
}

bool Contact::isContactEqual(Contact obj)
{
    if (first_name == obj.first_name && last_name == obj.last_name &&
        mobile_number == obj.mobile_number && email_address == obj.email_address &&
        address->isAddressEqual(*obj.address))
        return true;
    else
        return false;
}

bool Contact::operator==(const Contact& other) const
{

    // Compare all properties to check for equality
    return this->first_name == other.first_name &&
        this->last_name == other.last_name &&
        this->mobile_number == other.mobile_number &&
        this->email_address == other.email_address &&
        *(this->address) == *(other.address); // Compare addresses
}


std::ostream& operator <<(std::ostream& Cout, Contact& contact)
{
    Cout << contact.first_name << "," << contact.last_name
        << "," << contact.mobile_number << "," << contact.email_address << std::endl;
    Cout << *contact.address;
    return Cout;
}

void Contact::display_Contact()
{
    std::cout << "----Contact Information----" << std::endl;
    std::cout << "First name = " << first_name << std::endl;
    std::cout << "Last name = " << last_name << std::endl;
    std::cout << "Email = " << email_address << std::endl;
    std::cout << "Phone number = " << mobile_number << std::endl;
    std::cout << "Address =";
    if (address != nullptr)
    {
        address->printaddress();
    }
}
Contact& Contact::operator = (const Contact& contact)
{
    if (this != &contact)
    {
        this->first_name = contact.first_name;
        this->last_name = contact.last_name;
        this->mobile_number = contact.mobile_number;
        this->email_address = contact.email_address;
        this->address = contact.address;
    }
    else
        return *this;
}
Contact* Contact::copy_contact()
{
    Contact* obj = new Contact;
    obj->first_name = this->first_name;
    obj->last_name = this->last_name;
    obj->mobile_number = this->mobile_number;
    obj->email_address = this->email_address;
    obj->address = this->address;
    return obj;
}

void Contact::IncrementSearchCount()
{
    this->search_count++;
}
void  Contact::Update(Contact searched)
{

    *this = searched;

}
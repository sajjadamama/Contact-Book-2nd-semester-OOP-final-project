#include "Address.h"

Address::Address() {}

Address::Address(std::string house, std::string street, std::string city, std::string country)
{
    if (house.length() > 0)
        this->house = house;

    if (street.length() > 0)
        this->street = street;

    if (city.length() > 0)
        this->city = city;

    if (country.length() > 0)
        this->country = country;
}


void Address::setHouse(const std::string& house)
{
    if (house.length() > 0)
        this->house = house;
}
void Address::setStreet(const std::string& street) {
    if (street.length() > 0)
        this->street = street;
}
void Address::setCity(const std::string& city) {
    if (city.length() > 0)
        this->city = city;
}
void Address::setCountry(const std::string& country) {
    if (country.length() > 0)
        this->country = country;
}

std::string Address::getStreet() const
{
    return street;
}

std::string Address::getCity() const {
    return city;
}

std::string Address::getCountry() const {
    return country;
}

std::string Address::getHouse() const {
    return house;
}

Address& Address::operator = (const Address& address)
{
    if (this != &address)
    {
        this->house = address.house;
        this->street = address.street;
        this->city = address.city;
        this->country = address.country;
    }
    else
        return *this;
};

bool Address::operator==(const Address& obj) const
{
    return (street == obj.street && house == obj.house && country == obj.country && city == obj.city);
}

bool Address::isAddressEqual(const Address& obj) const
{
    return (*this == obj);
}

Address Address::copy_address()
{
    Address* add = new Address;
    add->setHouse(this->house);
    add->setStreet(this->street);
    add->setCity(this->city);
    add->setCountry(this->country);
    return *add;
}
std::ostream& operator <<(std::ostream& Cout, Address& address)
{
    Cout << address.house << "," << address.street << "," << address.city << "," << address.country << std::endl;
    return Cout;
};

void Address::printaddress() const
{
    std::cout << house << "/" << street << "/" << city << "/" << country << std::endl;
}

#pragma once
#pragma once
#pragma once
# include<iostream>
#include <string>

class Address {
private:
    std::string house;
    std::string street;
    std::string city;
    std::string country;

public:
    Address();
    Address(std::string house, std::string street, std::string city, std::string country);

    void setStreet(const std::string& street);
    void setCity(const std::string& city);
    void setCountry(const std::string& country);
    void setHouse(const std::string& house);

    std::string getStreet() const;
    std::string getCity() const;
    std::string getCountry() const;
    std::string getHouse() const;

    Address& operator = (const Address& address);
    friend std::ostream& operator <<(std::ostream& COUT, Address& address);
    bool operator==(const Address& other) const;
    bool isAddressEqual(const Address& other) const;
    Address copy_address();
    void printaddress() const;
};


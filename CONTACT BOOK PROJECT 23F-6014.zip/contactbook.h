#pragma once
#pragma once
#pragma once
#include "Contact.h"
#include <fstream>

class ContactBook
{
private:
    Contact* contacts_list;
    int size_of_contacts;
    int contacts_count;

public:

    void set_contacts_count(int);
    void add_contact(const Contact& contact);
    int total_contacts();

    Contact* search_contact(std::string first_name, std::string last_name);
    Contact* search_contact(std::string phone);
    Contact* search_contact(const Address& address);

    Contact single_string_contact(std::string String);

    ContactBook();
    ContactBook(int size_of_list);
    ~ContactBook();
    void print_contacts_sorted(std::string choice);
    ContactBook& operator=(const ContactBook& contacts_book);
    void merge_duplicates();
    void addContact(const Contact& contact);
    void load_from_file(std::string file_name);
    void save_to_file(std::string file_name);
    friend std::ostream& operator <<(std::ostream& COUT, ContactBook& contact);
    Contact* copy(Contact contact);
    bool is_duplicate(const Contact& contact) const;

    //extended functions
    Contact* get_contact_list();
    void ViewDetails(std::string input);
    void frequentlySearched();
    ContactBook Remove_contact(Contact contact);

private:
    bool isfull();
    void resize_list();
    void sort_contacts_list(Contact* contacts_list, std::string choice);
};
